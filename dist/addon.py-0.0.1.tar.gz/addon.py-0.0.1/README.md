# addon.py
An API Wrapper for the addon.to API.

## Installation
`pip install addon.py`

## How to use
Examples can be found in the examples folder. The documentation can be found [here](https://addonpy.readthedocs.io/en/latest/addon.html)
